#!/bin/sh
java -classpath config:lib/wizard.jar:lib/jxl.jar:lib/classes12.jar com.osa.dc.gwsb.GwsbWizard
