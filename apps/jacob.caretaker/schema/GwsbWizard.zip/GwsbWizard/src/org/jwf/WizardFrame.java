package org.jwf;

public class WizardFrame
{
}
