/*
 * Created on 29.03.2004
 */
package com.osa.dc.gwsb;

import java.util.HashMap;
import java.text.ParseException;

/**
 * @author Michael Buchfink
 */
public class GwsbData implements Comparable
{
  // the column types
  public static final int COL_OP          = 0;
  public static final int COL_AK          = 1;
  public static final int COL_CATEGORY    = 2;
  public static final int COL_PROCESS     = 3;
  public static final int COL_CONTRACT    = 4;
  public static final int COL_INFO        = 5;
  public static final int COL_SL          = 6;
  public static final int COL_KSL         = 7;
  public static final int COL_APPLICATION = 8;

  public static final int COL_UNKNOWN  = -1;

  /**
   * Contains the mapping for the headers.
   */
  private static HashMap mapping;
  static
  {
    mapping = new HashMap();

    // mappings for OP
    mapping.put("OP", new Integer(COL_OP));
    mapping.put("OPERATION", new Integer(COL_OP));
    mapping.put("ACTION", new Integer(COL_OP));

    // mappings for AK
    mapping.put("AK", new Integer(COL_AK));

    // mappings for CATEGORY
    mapping.put("CATEGORY", new Integer(COL_CATEGORY));
    mapping.put("GEWERK", new Integer(COL_CATEGORY));
    mapping.put("GEWERKEPFAD", new Integer(COL_CATEGORY));

    // mappings for PROCESS
    mapping.put("PROCESS", new Integer(COL_PROCESS));
    mapping.put("TAETIGKEIT", new Integer(COL_PROCESS));
    mapping.put("T�TIGKEIT", new Integer(COL_PROCESS));
    mapping.put("TAETIGKEITEN", new Integer(COL_PROCESS));
    mapping.put("T�TIGKEITEN", new Integer(COL_PROCESS));

    // mappings for CONTRACT
    mapping.put("CONTRACT", new Integer(COL_CONTRACT));
    mapping.put("VERTRAG", new Integer(COL_CONTRACT));

    // mappings for ROUTINGINFO
    mapping.put("ROUTINGINFO", new Integer(COL_INFO));
    mapping.put("INFO", new Integer(COL_INFO));

    // mappings for SL
    mapping.put("SL", new Integer(COL_SL));
    mapping.put("SERVICELEVEL", new Integer(COL_SL));
    mapping.put("SERVICE-LEVEL", new Integer(COL_SL));

    // mappings for KSL
    mapping.put("KSL", new Integer(COL_KSL));
    mapping.put("KRITISCHER SERVICELEVEL", new Integer(COL_KSL));
    mapping.put("KRITISCHER SERVICE-LEVEL", new Integer(COL_KSL));

    // mappings for APPLICATION
    mapping.put("APP", new Integer(COL_APPLICATION));
    mapping.put("APPL", new Integer(COL_APPLICATION));
    mapping.put("APPLICATION", new Integer(COL_APPLICATION));
    mapping.put("APPLICATION-KEY", new Integer(COL_APPLICATION));
  }

  /**
   * Specifies the row index
   */
  private long rowIndex;

  /**
   * Specifies the AK.
   */
  private boolean deleteOnly;

  /**
   * Specifies the AK.
   */
  private String ak;
  
  /**
   * Specifies the CATEGORY.
   */
  private String category;

  /**
   * Specifies the PROCESS.
   */
  private String process;

  /**
   * Specifies the CONTRACT.
   */
  private String contract;

  /**
   * Specifies the ROUTINGINFO.
   */
  private String routinginfo;

  /**
   * Specifies the SL.
   */
  private long sl;

  /**
   * Specifies the KSL.
   */
  private long ksl;

  /**
   * Specifies the APPLICATION.
   */
  private long applicationKey;

  /**
   * Specifies the error message
   */
  private String errorMessage;

  /**
   * Creates a new instance of GwsbData.
   */
  public GwsbData(long index)
  {
    rowIndex = index;

    deleteOnly = false;
    ak = null;
    category = null;
    process = null;
    contract = null;
    routinginfo = null;
    sl = 0;
    ksl = 0;
    applicationKey = 0;
    errorMessage = null;
  }

  /**
   * Compares this object with the specified object for order.
   */
  public int compareTo(Object o)
  {
    if (!(o instanceof GwsbData))
      throw new ClassCastException("not an instance of GwsbData");

    GwsbData cmp = (GwsbData)o;

    return (rowIndex < cmp.rowIndex ? -1 : (rowIndex == cmp.rowIndex ? 0 : 1));
  }

  /**
   * Returns true if all required members are set
   */
  public boolean isValid()
  {
    return (
        ak != null && category != null && process != null && contract != null
    );
  }

  /**
   * Parses and sets the column specified by columnType with the String value.
   */
  public void setColumn(int columnType, String value) throws ParseException
  {
    String preparsedValue = parseValue(value);

    switch (columnType)
    {
      case COL_OP:
        setUnparsedOp(preparsedValue);
        break;
      case COL_AK:
        setUnparsedAk(preparsedValue);
        break;
      case COL_CATEGORY:
        setUnparsedCategory(preparsedValue);
        break;
      case COL_PROCESS:
        setUnparsedProcess(preparsedValue);
        break;
      case COL_CONTRACT:
        setUnparsedContract(preparsedValue);
        break;
      case COL_INFO:
        setUnparsedRoutinginfo(preparsedValue);
        break;
      case COL_SL:
        setUnparsedSl(preparsedValue);
        break;
      case COL_KSL:
        setUnparsedKsl(preparsedValue);
        break;
      case COL_APPLICATION:
        setUnparsedApplicationKey(preparsedValue);
        break;
      default:
        throw new ParseException("cannot parse (" + columnType + "," + value + ")", 0);
    }
  }

  // GETTER

  /**
   * @return Returns the ak.
   */
  public String getAk()
  {
    return ak;
  }

  /**
   * @return Returns the applicationKey.
   */
  public long getApplicationKey()
  {
    return applicationKey;
  }

  /**
   * @return Returns the category.
   */
  public String getCategory()
  {
    return category;
  }

  /**
   * @return Returns the short name of the category.
   */
  public String getCategoryShort()
  {
    int idx = -1;
    if (category == null || (idx = category.lastIndexOf('/')) < 0)
      return category;

    return category.substring(idx + 1);
  }

  /**
   * @return Returns the contract.
   */
  public String getContract()
  {
    return contract;
  }

  /**
   * @return Returns the errorMessage.
   */
  public String getErrorMessage()
  {
    return errorMessage;
  }

  /**
   * @return Returns the ksl.
   */
  public long getKsl()
  {
    return ksl;
  }

  /**
   * @return Returns the process.
   */
  public String getProcess()
  {
    return process;
  }
  /**
   * @return Returns the routinginfo.
   */
  public String getRoutinginfo()
  {
    return routinginfo;
  }
 
  /**
   * @return Returns the sl.
   */
  public long getSl()
  {
    return sl;
  }

  /**
   * @return Returns the deleteOnly flag.
   */
  public boolean isDeleteOnly()
  {
    return deleteOnly;
  }

  // SETTER

  /**
   * @param ak The ak to set.
   */
  public void setAk(String ak)
  {
    this.ak = ak;
  }

  /**
   * @param applicationKey The applicationKey to set.
   */
  public void setApplicationKey(long applicationKey)
  {
    this.applicationKey = applicationKey;
  }

  /**
   * @param category The category to set.
   */
  public void setCategory(String category)
  {
    this.category = category;
  }

  /**
   * @param contract The contract to set.
   */
  public void setContract(String contract)
  {
    this.contract = contract;
  }
 
  /**
   * @param deleteOnly The deleteOnly flag to set.
   */
  public void setDeleteOnly(boolean deleteOnly)
  {
    this.deleteOnly = deleteOnly;
  }

  /**
   * @param errorMessage The errorMessage to set.
   */
  public void setErrorMessage(String errorMessage)
  {
    this.errorMessage = errorMessage;
  }

  /**
   * @param errorMessage The errorMessage to add.
   */
  public void addErrorMessage(String errorMessage)
  {
    if (this.errorMessage == null)
      setErrorMessage(errorMessage);
    else
      setErrorMessage(this.errorMessage + ", " + errorMessage);
  }

  /**
   * @param ksl The ksl to set.
   */
  public void setKsl(long ksl)
  {
    this.ksl = ksl;
  }

  /**
   * @param process The process to set.
   */
  public void setProcess(String process)
  {
    this.process = process;
  }
 
  /**
   * @param routinginfo The routinginfo to set.
   */
  public void setRoutinginfo(String routinginfo)
  {
    this.routinginfo = routinginfo;
  }

  /**
   * @param sl The sl to set.
   */
  public void setSl(long sl)
  {
    this.sl = sl;
  }

  /**
   * Creates a String representation of the object.
   */
  public String toString()
  {
    StringBuffer buffer = new StringBuffer();
    buffer.append("GwsbData[");
    buffer.append("rowIndex = ").append(rowIndex);
    buffer.append(", ak = ").append(ak);
    buffer.append(", category = ").append(category);
    buffer.append(", process = ").append(process);
    buffer.append(", contract = ").append(contract);
    buffer.append(", routinginfo = ").append(routinginfo);
    buffer.append(", sl = ").append(sl);
    buffer.append(", ksl = ").append(ksl);
    buffer.append(", applicationKey = ").append(applicationKey);
    buffer.append(", errorMessage = ").append(errorMessage);
    buffer.append("]");

    return buffer.toString();
  }

  // PRIVATE METHODS

  /**
   * @param value The ak to set.
   */
  private void setUnparsedAk(String value)
  {
    String suffix = "Vertragsleistungen von ";

    ak = value;
    if (ak != null && ak.startsWith(suffix))
      ak = ak.substring(suffix.length());
  }

  /**
   * @param value The ak to set.
   */
  private void setUnparsedApplicationKey(String value)
  {
    if (value == null)
      applicationKey = 0;
    else
    {
      try
      {
        applicationKey = Long.parseLong(value);
      }
      catch (NumberFormatException e)
      {} // ignore
    }
  }

  /**
   * @param value The category to set.
   */
  private void setUnparsedCategory(String value)
  {
    category = value;
  }

  /**
   * @param value The contract to set.
   */
  private void setUnparsedContract(String value)
  {
    contract = value;
  }
 
  /**
   * @param value The deleteOnly flag to set.
   */
  private void setUnparsedOp(String value)
  {
    if (value != null && (
        value.equalsIgnoreCase("D") ||
        value.equalsIgnoreCase("DELETE") ||
        value.equalsIgnoreCase("L") ||
        value.equalsIgnoreCase("L�SCHEN")
    ))
      deleteOnly = true;
  }

 /**
   * @param value The ksl to set.
   */
  private void setUnparsedKsl(String value) throws ParseException
  {
    ksl = parseServiceLevel(value);
  }

  /**
   * @param value The process to set.
   */
  private void setUnparsedProcess(String value)
  {
    process = value;
  }

  /**
   * @param value The routinginfo to set.
   */
  private void setUnparsedRoutinginfo(String value)
  {
    routinginfo = value;
  }

  /**
   * @param value The sl to set.
   */
  private void setUnparsedSl(String value) throws ParseException
  {
    sl = parseServiceLevel(value);
  }

  /**
   * Preparses value.
   */
  private String parseValue(String value)
  {
    if (value == null)
      return null;

    String parsedValue = value.trim();
    if (parsedValue.length() == 0 || parsedValue.equalsIgnoreCase("NULL"))
      return null;

    if (parsedValue.indexOf('\'') >= 0)
    {
      StringBuffer buffer = new StringBuffer(parsedValue);
      for (int idx = parsedValue.length()-1; idx >= 0; idx--)
        if (buffer.charAt(idx) == '\'')
          buffer.insert(idx, '\'');
    }

    return parsedValue;
  }

  /**
   * Parses service levels.
   */
  private long parseServiceLevel(String value) throws ParseException
  {
    if (value == null || value.equalsIgnoreCase("KEIN SL"))
      return 0;

    try
    {
      String tmp = value.toUpperCase();
      int endIdx = 0;
      while (endIdx < tmp.length())
      {
        if (!Character.isDigit(tmp.charAt(endIdx)))
          break;
        endIdx++;
      }

      long slValue = Long.parseLong(value.substring(0, endIdx));
      if (tmp.indexOf("TAG") > 0)                                   // calculate from days
        slValue *= (60*60*24);
      else if (tmp.indexOf("STUNDE") > 0 || tmp.indexOf("STD") > 0) // calculate from hours
        slValue *= (60*60);

      return slValue;
    }
    catch (NumberFormatException e)
    {
      throw new ParseException(e.toString(), 0);
    }
  }

  // STATIC METHODS

  /**
   * Returns the column type for the specified header. If there is no mapping,
   * then the value of COL_UNKNOWN will be returned.
   */
  public static int getColumnType(String header)
  {
    if (header != null)
    {
      Integer value = (Integer)mapping.get(header.toUpperCase());
      if (value != null)
        return value.intValue();
    }

    return COL_UNKNOWN;
  }
}
