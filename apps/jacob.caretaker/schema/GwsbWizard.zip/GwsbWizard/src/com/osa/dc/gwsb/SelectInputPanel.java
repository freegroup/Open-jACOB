/*
 * Created on 28.03.2004
 */
package com.osa.dc.gwsb;

import java.io.File;
import java.util.List;

import org.jwf.WizardPanel;

/**
 * @author Michael Buchfink
 *
 * Selects an excel file with GWSB data.
 */
public class SelectInputPanel extends SelectFilePanel
{

  /**
   * Contains the next wizard panel.
   */
  private WizardPanel nextPanel;

  /**
   * Constructs a new panel
   */
  public SelectInputPanel()
  {
    super("Auswahl der Excel-Datei zum Einlesen der GWSB-Daten");

    nextPanel = null;
  }

  /**
   * Called when the panel is set.
   */
  public void display()
  {
  }

  /**
   * Returns true because there is a successor panel.
   */
  public boolean hasNext()
  {
    return true;
  }

  /**
   * Called to validate the panel before finishing the wizard. Should
   * return false if canFinish returns false.
   * @param list a List of error messages to be displayed.
   * @return true if it is valid for this wizard to finish.
   */
  public boolean validateNext(List list)
  {
    String strFilename = textFilename.getText().trim();
    if (strFilename.length() == 0)
      list.add("Dateiname muss angegeben werden!");
    else
    {
      File inputFile = new File(strFilename);
      if (inputFile.isFile())
        wizardContext.setAttribute(GwsbWizard.CTX_INPUT_FILE, inputFile);
      else
        list.add("Datei existiert nicht!");
    }

    return list.size() == 0;
  }

  /**
   * Returns the next panel.
   */
  public WizardPanel next()
  {
    if (nextPanel == null)
      nextPanel = new ParseInputPanel();

    return nextPanel;
  }

  /**
   * Returns false, because this panel cannot finish the wizard
   */
  public boolean canFinish()
  {
    return false;
  }

  /**
   * Empty method.
   */
  public boolean validateFinish(List list)
  {
    return false;
  }

  /**
   * Empty method.
   */
  public void finish()
  {
  }
}