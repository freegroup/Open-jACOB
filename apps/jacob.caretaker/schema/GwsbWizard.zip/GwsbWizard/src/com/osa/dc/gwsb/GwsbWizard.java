/*
 * Created on 26.03.2004
 */
package com.osa.dc.gwsb;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

import org.jwf.Wizard;
import org.jwf.WizardListener;
import org.jwf.WizardPanel;

/**
 * @author Michael Buchfink
 *
 * Main application class
 */
public class GwsbWizard implements WizardListener, WindowListener
{
  /**
   * The context key for the database connection.
   */
  public static final String CTX_DB_CONNECTION = "dbConnection";

  /**
   * The context key for the output file.
   */
  public static final String CTX_OUTPUT_FILE = "outputFile";

  /**
   * The context key for the input file.
   */
  public static final String CTX_INPUT_FILE = "inputFile";

  /**
   * The context key for the sql file.
   */
  public static final String CTX_SQL_FILE = "sqlFile";

  /**
   * The context key for the error file.
   */
  public static final String CTX_ERROR_FILE = "errorFile";

  /**
   * The context key for the parsed input data.
   */
  public static final String CTX_INPUT_DATA = "inputData";

  /**
   * The context key for the hash maps.
   */
  public static final String CTX_HASH_MAPS = "hashMaps";

  /**
   * The context key for the database modification flag.
   */
  public static final String CTX_MODIFY_DATABASE = "modifyDatabase";

  /**
   * The context key for the service level support flag.
   */
  public static final String CTX_SUPPORT_SL = "supportSl";

  /**
   * The main application frame.
   */
  private JFrame frame;

  /**
   * Creates a new wizard frame.
   */
  public GwsbWizard() throws Exception
  {
    // get configuration data
    ResourceBundle bundle = PropertyResourceBundle.getBundle("Database");

    // initialize database connection
    Class.forName(bundle.getString("driver"));
    Connection connection = DriverManager.getConnection(bundle.getString("connection"));
    DatabaseMetaData metaData = connection.getMetaData();
    
    // output files
    File sqlFile = new File(bundle.getString("sqlFile"));
    File errorFile = new File(bundle.getString("errorFile"));

    frame = new JFrame("GWSB Wizard  [" + metaData.getUserName() + "]");
    try
    {
      frame.setIconImage(new ImageIcon(ClassLoader.getSystemResource("OSA-Logo-Neil.png")).getImage());
    }
    catch (Exception e)
    {} // ignore

    frame.addWindowListener(this);

    Wizard wizard = new Wizard();
    wizard.addWizardListener(this);

    frame.setContentPane(wizard);
    frame.pack();
    frame.setVisible(true);
    
    WizardPanel startPanel = new ContentsPanel();
    wizard.start(startPanel);
    startPanel.getWizardContext().setAttribute(CTX_DB_CONNECTION, connection);
    startPanel.getWizardContext().setAttribute(CTX_SQL_FILE, sqlFile);
    startPanel.getWizardContext().setAttribute(CTX_ERROR_FILE, errorFile);
  }

  // Implementation of WizardListener

  /**
   * Called when the wizard finishes.
   * @param wizard the wizard that finished.
   */
  public void wizardFinished(Wizard wizard)
  {
    System.exit(0);
  }

  /**
   * Called when the wizard is cancelled.
   * @param wizard the wizard that was cancelled.
   */
  public void wizardCancelled(Wizard wizard)
  {
    System.exit(0);
  }

  /**
   * Called when a new panel has been displayed in the wizard.
   * @param wizard the wizard that was updated
   */
  public void wizardPanelChanged(Wizard wizard)
  {
  }

  // Implementation of WindowListener

  /**
   * Invoked the first time a window is made visible.
   */
  public void windowOpened(WindowEvent e)
  {
  }

  /**
   * Invoked when the user attempts to close the window
   * from the window's system menu.  If the program does not 
   * explicitly hide or dispose the window while processing 
   * this event, the window close operation will be cancelled.
   */
  public void windowClosing(WindowEvent e)
  {
    System.exit(0);
  }

  /**
   * Invoked when a window has been closed as the result
   * of calling dispose on the window.
   */
  public void windowClosed(WindowEvent e)
  {
  }

  /**
   * Invoked when a window is changed from a normal to a
   * minimized state. For many platforms, a minimized window 
   * is displayed as the icon specified in the window's 
   * iconImage property.
   * @see java.awt.Frame#setIconImage
   */
  public void windowIconified(WindowEvent e)
  {
  }

  /**
   * Invoked when a window is changed from a minimized
   * to a normal state.
   */
  public void windowDeiconified(WindowEvent e)
  {
  }

  /**
   * Invoked when the Window is set to be the active Window. Only a Frame or
   * a Dialog can be the active Window. The native windowing system may
   * denote the active Window or its children with special decorations, such
   * as a highlighted title bar. The active Window is always either the
   * focused Window, or the first Frame or Dialog that is an owner of the
   * focused Window.
   */
  public void windowActivated(WindowEvent e)
  {
  }

  /**
   * Invoked when a Window is no longer the active Window. Only a Frame or a
   * Dialog can be the active Window. The native windowing system may denote
   * the active Window or its children with special decorations, such as a
   * highlighted title bar. The active Window is always either the focused
   * Window, or the first Frame or Dialog that is an owner of the focused
   * Window.
   */
  public void windowDeactivated(WindowEvent e)
  {
  }

  /**
   * Start the application.
   */
  public static void main(String[] args)
  {
    try
    {
      new GwsbWizard();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}
