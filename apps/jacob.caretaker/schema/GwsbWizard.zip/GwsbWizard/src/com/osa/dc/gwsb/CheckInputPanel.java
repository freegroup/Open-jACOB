/*
 * Created on 30.03.2004
 */
package com.osa.dc.gwsb;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

import javax.swing.JProgressBar;

import org.jwf.WizardPanel;

/**
 * @author Michael Buchfink
 *
 * Opens the given excel file, read and parse its input.
 */
public class CheckInputPanel extends WizardPanel implements Runnable
{
  /**
   * Contains the progress bar
   */
  private JProgressBar progressBar;

  /**
   * Contains the next wizard panel.
   */
  private WizardPanel nextPanel;

  /**
   * Contains the error message of the operation.
   */
  private String errorMessage;

  /**
   * Contains the activity thread.
   */
  private Thread activity;

  /**
   * Constructs a new panel
   */
  public CheckInputPanel()
  {
    super("�berpr�fe Datens�tze");

    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints constraints = new GridBagConstraints();
    constraints.insets = new Insets(3, 3, 3, 3);
    setLayout(gridbag);

    progressBar = new JProgressBar(JProgressBar.HORIZONTAL, 0, 100);
    progressBar.setString("Fortschritt");
    progressBar.setStringPainted(true);
    progressBar.setBorderPainted(true);
    progressBar.setPreferredSize(new Dimension(400, 20));
    constraints.gridx = 0;
    constraints.gridy = 0;
    constraints.anchor = GridBagConstraints.EAST;
    gridbag.setConstraints(progressBar, constraints);
    add(progressBar);

    nextPanel = null;
    errorMessage = null;
    activity = null;
  }

  /**
   * Called when the panel is set.
   */
  public void display()
  {
    if (activity == null)
    {
      activity = new Thread(this);
      activity.start();
    }
  }

  /**
   * The activity thread
   */
  public void run()
  {
    setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

    LinkedList inputData = (LinkedList)wizardContext.getAttribute(GwsbWizard.CTX_INPUT_DATA);
    Connection connection = (Connection)wizardContext.getAttribute(GwsbWizard.CTX_DB_CONNECTION);

    TreeSet categorySet    = new TreeSet();       // Gewerkepfade
    TreeSet akSet          = new TreeSet();       // AKs
    TreeSet processSet     = new TreeSet();       // T�tigkeiten
    TreeSet contractSet    = new TreeSet();       // Vertr�ge
    TreeSet applicationSet = new TreeSet();       // Applicationen

    HashMap[] maps = new HashMap[5];
    wizardContext.setAttribute(GwsbWizard.CTX_HASH_MAPS, maps);

    HashMap categoryMap    = maps[0] = new HashMap(); // Gewerke-Ids
    HashMap akMap          = maps[1] = new HashMap(); // AK-Ids
    HashMap processMap     = maps[2] = new HashMap(); // T�tigkeits-Ids
    HashMap contractMap    = maps[3] = new HashMap(); // Vertrags-Ids
    HashMap applicationMap = maps[4] = new HashMap(); // Application-Ids

    progressBar.setString("Analyse der Daten");
    progressBar.setValue(0);

    // collect columns
    int maxIdx = inputData.size();
    int idx = 0;
    Iterator i = inputData.iterator();
    while (i.hasNext())
    {
      setProcessValue(idx++, maxIdx);
      GwsbData data = (GwsbData)i.next();
      if (data.isValid())
      {
        categorySet.add(data.getCategory());
        akSet.add(data.getAk());
        processSet.add(data.getProcess());
        contractSet.add(data.getContract());
        if (data.getApplicationKey() > 0)
          applicationSet.add(new Long(data.getApplicationKey()));
      }
    }

    try
    {
      // category check
      progressBar.setString("�berpr�fe Gewerke");
      progressBar.setValue(0);

      maxIdx = categorySet.size();
      idx = 0;
      i = categorySet.iterator();
      while (i.hasNext())
      {
        setProcessValue(idx++, maxIdx);
        String strCategory = (String)i.next();

        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT PKEY FROM CATEGORY WHERE CATEGORYSTATUS<>7 AND LONGNAME='" + strCategory + "'");

        if (resultSet.next())
          categoryMap.put(strCategory, resultSet.getString(1));

        resultSet.close();
        statement.close();
      }

      // ak check
      progressBar.setString("�berpr�fe AKs");
      progressBar.setValue(0);

      maxIdx = akSet.size();
      idx = 0;
      i = akSet.iterator();
      while (i.hasNext())
      {
        setProcessValue(idx++, maxIdx);
        String strAk = (String)i.next();

        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT PKEY FROM WORKGROUP WHERE NAME='" + strAk + "' AND GROUPSTATUS<>7");

        if (resultSet.next())
          akMap.put(strAk, resultSet.getString(1));

        resultSet.close();
        statement.close();
      }

      // process check
      progressBar.setString("�berpr�fe T�tigkeiten");
      progressBar.setValue(0);

      maxIdx = processSet.size();
      idx = 0;
      i = processSet.iterator();
      while (i.hasNext())
      {
        setProcessValue(idx++, maxIdx);
        String strProcess = (String)i.next();

        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT PKEY FROM PROCESS WHERE PROCESSNAME='" + strProcess + "' AND PROCESSSTATUS<>7");

        if (resultSet.next())
          processMap.put(strProcess, resultSet.getString(1));

        resultSet.close();
        statement.close();
      }

      // contract check
      progressBar.setString("�berpr�fe Vertragsdaten");
      progressBar.setValue(0);

      maxIdx = contractSet.size();
      idx = 0;
      i = contractSet.iterator();
      while (i.hasNext())
      {
        setProcessValue(idx++, maxIdx);
        String strContract = (String)i.next();

        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT PKEY FROM CONTRACT WHERE CONTRACTNUM='" + strContract + "' AND CONTRACTSTATUS<>7");

        if (resultSet.next())
          contractMap.put(strContract, resultSet.getString(1));

        resultSet.close();
        statement.close();
      }
 
      // application check
      progressBar.setString("�berpr�fe Applikationen");
      progressBar.setValue(0);

      maxIdx = applicationSet.size();
      idx = 0;
      i = applicationSet.iterator();
      while (i.hasNext())
      {
        setProcessValue(idx++, maxIdx);
        Long applicationKey = (Long)i.next();

        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT PKEY FROM APPLICATIONPROCESS WHERE PKEY='" + applicationKey.toString() + "'");

        if (resultSet.next())
          applicationMap.put(applicationKey, resultSet.getString(1));

        resultSet.close();
        statement.close();
      }

      errorMessage = null;
      progressBar.setString("Fertig");
      progressBar.setValue(100);
    }
    catch (Exception e)
    {
      progressBar.setString("Fehler");
      errorMessage = "Error: " + e.toString();
    }

    setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
    activity = null;
  }

  /**
   * Returns true because there is a successor panel.
   */
  public boolean hasNext()
  {
    return true;
  }

  /**
   * Called to validate the panel before finishing the wizard. Should
   * return false if canFinish returns false.
   * @param list a List of error messages to be displayed.
   * @return true if it is valid for this wizard to finish.
   */
  public boolean validateNext(List list)
  {
    if (activity == null && (errorMessage == null || errorMessage.length() == 0))
      return true;

    if (activity != null)
      list.add("Aktivit�t noch nicht abgeschlossen");

    list.add(errorMessage);
    return false;
  }

  /**
   * Returns the next panel.
   */
  public WizardPanel next()
  {
    if (nextPanel == null)
      nextPanel = new WriteOutputPanel();

    return nextPanel;
  }

  /**
   * Returns false, because this panel cannot finish the wizard
   */
  public boolean canFinish()
  {
    return false;
  }

  /**
   * Empty method.
   */
  public boolean validateFinish(List list)
  {
    return false;
  }

  /**
   * Empty method.
   */
  public void finish()
  {
  }

  /**
   * Sets the value of the progress bar.
   */
  private void setProcessValue(int current, int max)
  {
    if (max > 0)
    {
      int value = (100*(current + 1))/max;
      if (value != progressBar.getValue())
        progressBar.setValue(value);
    }
  }
}
