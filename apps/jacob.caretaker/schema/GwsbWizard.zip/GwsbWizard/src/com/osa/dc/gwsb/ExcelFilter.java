/*
 * Created on 29.03.2004
 */
package com.osa.dc.gwsb;

import java.io.File;

import javax.swing.filechooser.FileFilter;

/**
 * @author Michael Buchfink
 *
 * File filter used for ms excel files.
 */
public class ExcelFilter extends FileFilter
{

  /**
   * Constructs a new ExcelFilter.
   */
  public ExcelFilter()
  {
    super();
  }

  /**
   * Whether the given file is accepted by this filter. This is the case if its
   * an directory or an filename with the extension XSL.
   */
  public boolean accept(File f)
  {
    if (f.isDirectory())
      return true;
    
    String filename = f.getName();
    return (filename.length() > 4 && filename.substring(filename.length()-4).equalsIgnoreCase(".XLS"));
  }

  /**
   *  The description of this filter.
   */
  public String getDescription()
  {
    return "MS-Excel-Arbeitsblatt";
  }
}
