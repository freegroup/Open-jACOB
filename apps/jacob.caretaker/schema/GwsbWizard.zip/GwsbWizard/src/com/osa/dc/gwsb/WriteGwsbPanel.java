/*
 * Created on 12.04.2004
 */
package com.osa.dc.gwsb;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.io.File;
import java.util.List;

import javax.swing.JProgressBar;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.jwf.WizardPanel;

/**
 * @author Michael Buchfink
 *
 * Writes the GWSB data to an MS-Excel file.
 */
public class WriteGwsbPanel extends WizardPanel implements Runnable
{
  private static final int IDX_OP          = 0;
  private static final int IDX_APPLICATION = 1;
  private static final int IDX_AK          = 2;
  private static final int IDX_GEWERK      = 3;
  private static final int IDX_TAETIGKEIT  = 4;
  private static final int IDX_VERTRAG     = 5;
  private static final int IDX_SL          = 6;
  private static final int IDX_KSL         = 7;
  private static final int IDX_ROUTINGINFO = 8;
  private static final int IDX_GEWERKEPFAD = 9;

  /**
   * Contains the progress bar.
   */
  private JProgressBar progressBar;

  /**
   * Contains the error message of the operation.
   */
  private String errorMessage;

  /**
   * Contains the activity thread.
   */
  private Thread activity;

  /**
   * Constructs a new panel.
   */
  public WriteGwsbPanel()
  {
    super("Generierung der Excel-Datei");

    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints constraints = new GridBagConstraints();
    constraints.insets = new Insets(3, 3, 3, 3);
    setLayout(gridbag);

    progressBar = new JProgressBar(JProgressBar.HORIZONTAL, 0, 100);
    progressBar.setString("Fortschritt");
    progressBar.setStringPainted(true);
    progressBar.setBorderPainted(true);
    progressBar.setPreferredSize(new Dimension(400, 20));
    constraints.gridx = 0;
    constraints.gridy = 0;
    constraints.anchor = GridBagConstraints.EAST;
    gridbag.setConstraints(progressBar, constraints);
    add(progressBar);

    errorMessage = null;
    activity = null;
  }

  /**
   * Called when the panel is set.
   */
  public void display()
  {
    if (activity == null)
    {
      activity = new Thread(this);
      activity.start();
    }
  }

  /**
   * The activity thread.
   */
  public void run()
  {
    setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

    progressBar.setString("Fortschritt");
    progressBar.setValue(0);
    try
    {
      WritableWorkbook workbook = Workbook.createWorkbook(
          (File)wizardContext.getAttribute(GwsbWizard.CTX_OUTPUT_FILE)
      );
      WritableSheet sheet = workbook.createSheet("GWSB", 0);
      // write header
      sheet.addCell(new Label(IDX_OP, 0, "OP"));
      sheet.addCell(new Label(IDX_APPLICATION, 0, "APPL"));
      sheet.addCell(new Label(IDX_AK, 0, "AK"));
      sheet.addCell(new Label(IDX_GEWERK, 0, "GEWERK"));
      sheet.addCell(new Label(IDX_TAETIGKEIT, 0, "TAETIGKEIT"));
      sheet.addCell(new Label(IDX_VERTRAG, 0, "VERTRAG"));
      sheet.addCell(new Label(IDX_SL, 0, "SL"));
      sheet.addCell(new Label(IDX_KSL, 0, "KSL"));
      sheet.addCell(new Label(IDX_ROUTINGINFO, 0, "ROUTINGINFO"));
      sheet.addCell(new Label(IDX_GEWERKEPFAD, 0, "GEWERKEPFAD"));

      // insert data from the database
      Connection connection = (Connection)wizardContext.getAttribute(GwsbWizard.CTX_DB_CONNECTION);

      StringBuffer selectCmd = new StringBuffer("SELECT WORKGROUP.NAME AS AK");
      selectCmd.append(",CATEGORY.NAME AS GEWERK");
      selectCmd.append(",PROCESS.PROCESSNAME AS TAETIGKEIT");
      selectCmd.append(",CONTRACT.CONTRACTNUM AS VERTRAG");
      selectCmd.append(",CONTRACTSL.SL AS SL");
      selectCmd.append(",CONTRACTSL.KSL AS KSL");
      selectCmd.append(",CATEGORYPROCESS.ROUTINGINFO AS ROUTINGINFO");
      selectCmd.append(",CATEGORYPROCESS.APPLICATION_KEY AS APPLICATION");
      selectCmd.append(",CATEGORY.LONGNAME AS GEWERKEPFAD");
      StringBuffer fromCmd = new StringBuffer("FROM CATEGORYPROCESS,CATEGORY,WORKGROUP,PROCESS,CONTRACT,CONTRACTSL");
      StringBuffer whereCmd = new StringBuffer("WHERE CATEGORYPROCESS.WORKGROUP_KEY=WORKGROUP.PKEY");
      whereCmd.append(" AND CATEGORYPROCESS.CATEGORY_KEY=CATEGORY.PKEY");
      whereCmd.append(" AND CATEGORYPROCESS.PROCESS_KEY=PROCESS.PKEY");
      whereCmd.append(" AND CATEGORYPROCESS.CONTRACT_KEY=CONTRACT.PKEY");
      whereCmd.append(" AND CATEGORYPROCESS.CATEGORY_KEY=CONTRACTSL.CATEGORY_KEY(+)");
      whereCmd.append(" AND CATEGORYPROCESS.PROCESS_KEY=CONTRACTSL.PROCESS_KEY(+)");
      whereCmd.append(" AND CATEGORYPROCESS.CONTRACT_KEY=CONTRACTSL.CONTRACT_KEY(+)");
      whereCmd.append(" AND WORKGROUP.GROUPSTATUS<>7");
      whereCmd.append(" AND CATEGORY.CATEGORYSTATUS<>7");
      whereCmd.append(" AND PROCESS.PROCESSSTATUS<>7");
      whereCmd.append(" AND CONTRACT.CONTRACTSTATUS<>7");
      // whereCmd.append(" AND ROWNUM<100");
      StringBuffer orderCmd = new StringBuffer("ORDER BY AK,GEWERK,TAETIGKEIT,VERTRAG");

      StringBuffer sqlCmd = new StringBuffer("SELECT COUNT(*)");
      sqlCmd.append(" ").append(fromCmd);
      sqlCmd.append(" ").append(whereCmd);

      // calculate number of instances
      Statement statement = connection.createStatement();
      ResultSet resultSet = statement.executeQuery(sqlCmd.toString());
      int rowCount = resultSet.next() ? resultSet.getInt(1) : 0;
      resultSet.close();
      statement.close();

      // get instances
      sqlCmd = new StringBuffer(selectCmd.toString());
      sqlCmd.append(" ").append(fromCmd);
      sqlCmd.append(" ").append(whereCmd);
      sqlCmd.append(" ").append(orderCmd);

      int count = 0;
      statement = connection.createStatement();
      resultSet = statement.executeQuery(sqlCmd.toString());
      while (resultSet.next())
      {
        setProcessValue(count++, rowCount);

        sheet.addCell(new Label(IDX_OP, count, ""));
        sheet.addCell(new Label(IDX_APPLICATION, count, resultSet.getString("APPLICATION")));
        sheet.addCell(new Label(IDX_AK, count, resultSet.getString("AK")));
        sheet.addCell(new Label(IDX_GEWERK, count, resultSet.getString("GEWERK")));
        sheet.addCell(new Label(IDX_TAETIGKEIT, count, resultSet.getString("TAETIGKEIT")));
        sheet.addCell(new Label(IDX_VERTRAG, count, resultSet.getString("VERTRAG")));
        sheet.addCell(new Label(IDX_SL, count, resultSet.getString("SL")));
        sheet.addCell(new Label(IDX_KSL, count, resultSet.getString("KSL")));
        sheet.addCell(new Label(IDX_ROUTINGINFO, count, resultSet.getString("ROUTINGINFO")));
        sheet.addCell(new Label(IDX_GEWERKEPFAD, count, resultSet.getString("GEWERKEPFAD")));
      }
      resultSet.close();
      statement.close();

      // all sheets and cells added. Now write out the workbook 
      workbook.write(); 
      workbook.close(); 

      errorMessage = null;
      progressBar.setString("Fertig");
      progressBar.setValue(100);
    }
    catch (Exception e)
    {
      progressBar.setString("Fehler");
      errorMessage = "Error: " + e.toString();
    }

    setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
    activity = null;
  }

  /**
   * Returns false because there is no successor panel.
   */
  public boolean hasNext()
  {
    return false;
  }

  /**
   * Returns false because there is no successor panel.
   */
  public boolean validateNext(List list)
  {
    return false;
  }

  /**
   * Returns null because there is no successor panel.
   */
  public WizardPanel next()
  {
    return null;
  }

  /**
   * Returns true, because this panel can finish the wizard.
   */
  public boolean canFinish()
  {
    return true;
  }

  /**
   * Empty method.
   */
  public boolean validateFinish(List list)
  {
    if (activity == null && (errorMessage == null || errorMessage.length() == 0))
      return true;

    if (activity != null)
      list.add("Aktivit�t noch nicht abgeschlossen");

    list.add(errorMessage);
    return false;
  }

  /**
   * Empty method.
   */
  public void finish()
  {
  }

  /**
   * Sets the value of the progress bar.
   */
  private void setProcessValue(int current, int max)
  {
    if (max > 0)
    {
      int value = (100*(current + 1))/max;
      if (value != progressBar.getValue())
        progressBar.setValue(value);
    }
  }
}
