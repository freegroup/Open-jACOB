/*
 * Created on 28.03.2004
 */
package com.osa.dc.gwsb;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JTextField;

import org.jwf.WizardPanel;

/**
 * @author Michael Buchfink
 * 
 * Select an excel file
 */
public abstract class SelectFilePanel extends WizardPanel implements ActionListener
{

  public static final String STR_SEARCH = "Durchsuchen";

  /**
   * Contains the filename of the excel file
   */
  protected JTextField textFilename;

  /**
   * Constructs a new panel
   */
  public SelectFilePanel(String name)
  {
    super(name);

    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints constraints = new GridBagConstraints();
    constraints.insets = new Insets(3, 3, 3, 3);
    setLayout(gridbag);

    JLabel labelName = new JLabel("Name:");
    constraints.gridx = 0;
    constraints.gridy = 0;
    constraints.anchor = GridBagConstraints.EAST;
    gridbag.setConstraints(labelName, constraints);
    add(labelName);

    textFilename = new JTextField(25);
    constraints.gridx = 1;
    constraints.gridy = 0;
    constraints.anchor = GridBagConstraints.WEST;
    gridbag.setConstraints(textFilename, constraints);
    add(textFilename);

    JButton buttonSearch = new JButton(STR_SEARCH);
    buttonSearch.addActionListener(this);
    constraints.gridx = 2;
    constraints.gridy = 0;
    constraints.anchor = GridBagConstraints.WEST;
    gridbag.setConstraints(buttonSearch, constraints);
    add(buttonSearch);
  }

  // Implementation of ActionListener

  /**
   * Handle's button presses.
   * 
   * @param actionEvent
   *          an ActionEvent object
   */
  public void actionPerformed(ActionEvent actionEvent)
  {
    String actionCommand = actionEvent.getActionCommand();
    if (STR_SEARCH.equals(actionCommand))
      selectFilename();
  }

  /**
   * Opens a fileselection dialog for filename input.
   */
  private void selectFilename()
  {
    ExcelFilter filter = new ExcelFilter();
    String strFilename = textFilename.getText().trim();
    JFileChooser chooser = new JFileChooser();
    chooser.addChoosableFileFilter(filter);
    if (strFilename.length() > 0)
      chooser.setSelectedFile(new File(strFilename));
    else
      chooser.setCurrentDirectory(new File("."));
    
    if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
    {
      if (!filter.accept(chooser.getSelectedFile()))
        textFilename.setText(chooser.getSelectedFile().getPath() + ".xls");
      else
        textFilename.setText(chooser.getSelectedFile().getPath());
    }
  }
}