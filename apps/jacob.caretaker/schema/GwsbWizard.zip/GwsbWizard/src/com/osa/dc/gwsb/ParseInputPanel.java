/*
 * Created on 29.03.2004
 */
package com.osa.dc.gwsb;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.File;
import java.util.List;
import java.util.LinkedList;
import java.text.ParseException;

import javax.swing.JProgressBar;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

import org.jwf.WizardPanel;

/**
 * @author Michael Buchfink
 *
 * Opens the given excel file, read and parse its input.
 */
public class ParseInputPanel extends WizardPanel implements Runnable
{
  /**
   * Contains the progress bar
   */
  private JProgressBar progressBar;

  /**
   * Contains the next wizard panel.
   */
  private WizardPanel nextPanel;

  /**
   * Contains the error message of the operation.
   */
  private String errorMessage;

  /**
   * Contains the activity thread.
   */
  private Thread activity;

  /**
   * Constructs a new panel
   */
  public ParseInputPanel()
  {
    super("Einlesen der Excel-Datei");

    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints constraints = new GridBagConstraints();
    constraints.insets = new Insets(3, 3, 3, 3);
    setLayout(gridbag);

    progressBar = new JProgressBar(JProgressBar.HORIZONTAL, 0, 100);
    progressBar.setString("Fortschritt");
    progressBar.setStringPainted(true);
    progressBar.setBorderPainted(true);
    progressBar.setPreferredSize(new Dimension(400, 20));
    constraints.gridx = 0;
    constraints.gridy = 0;
    constraints.anchor = GridBagConstraints.EAST;
    gridbag.setConstraints(progressBar, constraints);
    add(progressBar);

    nextPanel = null;
    errorMessage = null;
    activity = null;
  }

  /**
   * Called when the panel is set.
   */
  public void display()
  {
    if (activity == null)
    {
      activity = new Thread(this);
      activity.start();
    }
  }

  /**
   * The activity thread
   */
  public void run()
  {
    setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

    LinkedList inputData = new LinkedList();
    wizardContext.setAttribute(GwsbWizard.CTX_INPUT_DATA, inputData);
    File inputFile = (File)wizardContext.getAttribute(GwsbWizard.CTX_INPUT_FILE);
    progressBar.setString("Fortschritt");
    progressBar.setValue(0);
    try
    {
      Workbook workbook = Workbook.getWorkbook(inputFile);
      Sheet sheet = workbook.getSheet(0);
      int rowNum = sheet.getRows();
      if (rowNum > 0)
      {
        Cell[] header = sheet.getRow(0);
        int[] columnTypes = new int[header.length];
        for (int colIdx = 0; colIdx < header.length; colIdx++)
          columnTypes[colIdx] = GwsbData.getColumnType(header[colIdx].getContents());

        for (int rowIdx = 1; rowIdx < rowNum; rowIdx++)
        {
          setProcessValue(rowIdx, rowNum);

          GwsbData data = new GwsbData(rowIdx+1);
          Cell[] row = sheet.getRow(rowIdx);
          try
          {
            for (int colIdx = 0; colIdx < Math.min(row.length, header.length); colIdx++)
            {
              if (columnTypes[colIdx] != GwsbData.COL_UNKNOWN)
                data.setColumn(columnTypes[colIdx], row[colIdx].getContents());
            }
          }
          catch (ParseException e)
          {
            data.addErrorMessage("Fehler beim Parsen");
          } 
          inputData.add(data);
        }
      }

      errorMessage = null;
      progressBar.setString("Fertig");
      progressBar.setValue(100);
    }
    catch (Exception e)
    {
      progressBar.setString("Fehler");
      errorMessage = "Error: " + e.toString();
    }

    setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
    activity = null;
  }
  
  /**
   * Returns true because there is a successor panel.
   */
  public boolean hasNext()
  {
    return true;
  }

  /**
   * Called to validate the panel before finishing the wizard. Should
   * return false if canFinish returns false.
   * @param list a List of error messages to be displayed.
   * @return true if it is valid for this wizard to finish.
   */
  public boolean validateNext(List list)
  {
    if (activity == null && (errorMessage == null || errorMessage.length() == 0))
      return true;

    if (activity != null)
      list.add("Aktivit�t noch nicht abgeschlossen");

    list.add(errorMessage);
    return false;
  }

  /**
   * Returns the next panel.
   */
  public WizardPanel next()
  {
    if (nextPanel == null)
      nextPanel = new ModifyDBPanel();

    return nextPanel;
  }

  /**
   * Returns false, because this panel cannot finish the wizard
   */
  public boolean canFinish()
  {
    return false;
  }

  /**
   * Empty method.
   */
  public boolean validateFinish(List list)
  {
    return false;
  }

  /**
   * Empty method.
   */
  public void finish()
  {
  }

  /**
   * Sets the value of the progress bar.
   */
  private void setProcessValue(int current, int max)
  {
    if (max > 0)
    {
      int value = (100*(current + 1))/max;
      if (value != progressBar.getValue())
        progressBar.setValue(value);
    }
  }
}
