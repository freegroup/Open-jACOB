/*
 * Created on 28.03.2004
 */
package com.osa.dc.gwsb;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;

import org.jwf.WizardPanel;

/**
 * @author Michael Buchfink
 *
 * Main Contents panel.
 */
public class ContentsPanel extends WizardPanel
{
  public static final String CMD_CREATE_FILE   = "Excel-Datei erzeugen";
  public static final String CMD_EVALUATE_FILE = "Excel-Datei auswerten";

  /**
   * Contains the creation panel.
   */
  private WizardPanel creationPanel;
  
  /**
   * Contains the evaluation panel.
   */
  private WizardPanel evaluationPanel;

  /**
   * Contains the radio buttons for the navigation.
   */
  private ButtonGroup buttonGroup;

  /**
   * Constructs a new panel
   */
  public ContentsPanel()
  {
    super("Auswahl der Operation");

    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints constraints = new GridBagConstraints();
    constraints.insets = new Insets(3, 3, 3, 3);
    setLayout(gridbag);

    buttonGroup = new ButtonGroup();

    JRadioButton creationButton = new JRadioButton(CMD_CREATE_FILE, true);
    creationButton.setActionCommand(CMD_CREATE_FILE);
    buttonGroup.add(creationButton);
    constraints.gridx = 0;
    constraints.gridy = 0;
    constraints.anchor = GridBagConstraints.WEST;
    gridbag.setConstraints(creationButton, constraints);
    add(creationButton);

    JRadioButton evaluationButton = new JRadioButton(CMD_EVALUATE_FILE, false);
    evaluationButton.setActionCommand(CMD_EVALUATE_FILE);
    buttonGroup.add(evaluationButton);
    constraints.gridx = 0;
    constraints.gridy = 1;
    constraints.anchor = GridBagConstraints.WEST;
    gridbag.setConstraints(evaluationButton, constraints);
    add(evaluationButton);

    creationPanel = null;
    evaluationPanel = null;
  }

  /**
   * Called when the panel is set.
   */
  public void display()
  {
  }

  /**
   * Returns true because there is a successor panel.
   */
  public boolean hasNext()
  {
    return true;
  }

  /**
   * Called to validate the panel before finishing the wizard. Should
   * return false if canFinish returns false.
   * @param list a List of error messages to be displayed.
   * @return true if it is valid for this wizard to finish.
   */
  public boolean validateNext(List list)
  {
    return true;
  }

  /**
   * Returns the next panel.
   */
  public WizardPanel next()
  {
    WizardPanel nextPanel = null;
    String cmdSelected = buttonGroup.getSelection().getActionCommand();
    if (CMD_CREATE_FILE.equals(cmdSelected))
    {
      if (creationPanel == null)
        creationPanel = new SelectOutputPanel();
      nextPanel = creationPanel;
    }
    else if (CMD_EVALUATE_FILE.equals(cmdSelected))
    {
      if (evaluationPanel == null)
        evaluationPanel = new SelectInputPanel();
      nextPanel = evaluationPanel;
    }

    return nextPanel;
  }

  /**
   * Returns false, because this panel cannot finish the wizard
   */
  public boolean canFinish()
  {
    return false;
  }

  /**
   * Empty method.
   */
  public boolean validateFinish(List list)
  {
    return false;
  }

  /**
   * Empty method.
   */
  public void finish()
  {
  }
}
