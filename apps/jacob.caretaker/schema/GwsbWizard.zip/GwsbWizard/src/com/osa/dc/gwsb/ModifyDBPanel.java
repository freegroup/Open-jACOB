/*
 * Created on 28.03.2004
 */
package com.osa.dc.gwsb;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;

import javax.swing.JCheckBox;

import org.jwf.WizardPanel;

/**
 * @author Michael Buchfink
 * 
 * Selection for database modifications.
 */
public class ModifyDBPanel extends WizardPanel
{

  /**
   * Contains the next wizard panel.
   */
  private WizardPanel nextPanel;

  /**
   * Contains the radio buttons for the navigation.
   */
  private JCheckBox modifyDB;

  /**
   * Contains the radio buttons for the navigation.
   */
  private JCheckBox supportSL;

  /**
   * Constructs a new panel
   */
  public ModifyDBPanel()
  {
    super("Datenbank modifizieren");

    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints constraints = new GridBagConstraints();
    constraints.insets = new Insets(3, 3, 3, 3);
    setLayout(gridbag);

    modifyDB = new JCheckBox("Datenbank modifizieren");
    constraints.gridx = 0;
    constraints.gridy = 0;
    constraints.anchor = GridBagConstraints.WEST;
    gridbag.setConstraints(modifyDB, constraints);
    add(modifyDB);

    supportSL = new JCheckBox("Service Level schreiben");
    constraints.gridx = 0;
    constraints.gridy = 1;
    constraints.anchor = GridBagConstraints.WEST;
    gridbag.setConstraints(supportSL, constraints);
    add(supportSL);

    nextPanel = null;
  }

  /**
   * Called when the panel is set.
   */
  public void display()
  {
  }

  /**
   * Returns true because there is a successor panel.
   */
  public boolean hasNext()
  {
    return true;
  }

  /**
   * Called to validate the panel before finishing the wizard. Should return
   * false if canFinish returns false.
   * 
   * @param list
   *          a List of error messages to be displayed.
   * @return true if it is valid for this wizard to finish.
   */
  public boolean validateNext(List list)
  {
    if (modifyDB.isSelected())
      wizardContext.setAttribute(GwsbWizard.CTX_MODIFY_DATABASE, new Boolean(true));
    else
      wizardContext.setAttribute(GwsbWizard.CTX_MODIFY_DATABASE, new Boolean(false));

    if (supportSL.isSelected())
      wizardContext.setAttribute(GwsbWizard.CTX_SUPPORT_SL, new Boolean(true));
    else
      wizardContext.setAttribute(GwsbWizard.CTX_SUPPORT_SL, new Boolean(false));

    return true;
  }

  /**
   * Returns the next panel.
   */
  public WizardPanel next()
  {
    if (nextPanel == null)
      nextPanel = new CheckInputPanel();

    return nextPanel;
  }

  /**
   * Returns false, because this panel cannot finish the wizard
   */
  public boolean canFinish()
  {
    return false;
  }

  /**
   * Empty method.
   */
  public boolean validateFinish(List list)
  {
    return false;
  }

  /**
   * Empty method.
   */
  public void finish()
  {
  }
}