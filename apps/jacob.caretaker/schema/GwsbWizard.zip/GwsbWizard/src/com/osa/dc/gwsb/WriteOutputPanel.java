/*
 * Created on 29.03.2004
 */
package com.osa.dc.gwsb;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

import javax.swing.JProgressBar;

import org.jwf.WizardPanel;

/**
 * @author Michael Buchfink
 *
 * Opens the given excel file, read and parse its input.
 */
public class WriteOutputPanel extends WizardPanel implements Runnable
{
  /**
   * Contains the progress bar
   */
  private JProgressBar progressBar;

  /**
   * Contains the error message of the operation.
   */
  private String errorMessage;

  /**
   * Contains the activity thread.
   */
  private Thread activity;

  /**
   * Constructs a new panel
   */
  public WriteOutputPanel()
  {
    super("Generierung der SQL-Scripte");

    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints constraints = new GridBagConstraints();
    constraints.insets = new Insets(3, 3, 3, 3);
    setLayout(gridbag);

    progressBar = new JProgressBar(JProgressBar.HORIZONTAL, 0, 100);
    progressBar.setString("Fortschritt");
    progressBar.setStringPainted(true);
    progressBar.setBorderPainted(true);
    progressBar.setPreferredSize(new Dimension(400, 20));
    constraints.gridx = 0;
    constraints.gridy = 0;
    constraints.anchor = GridBagConstraints.EAST;
    gridbag.setConstraints(progressBar, constraints);
    add(progressBar);

    errorMessage = null;
    activity = null;
  }

  /**
   * Called when the panel is set.
   */
  public void display()
  {
    if (activity == null)
    {
      activity = new Thread(this);
      activity.start();
    }
  }

  /**
   * The activity thread
   */
  public void run()
  {
    setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

    Connection connection = null;
    Boolean modifyDb = (Boolean)wizardContext.getAttribute(GwsbWizard.CTX_MODIFY_DATABASE);
    if (modifyDb != null && modifyDb.booleanValue())
      connection = (Connection)wizardContext.getAttribute(GwsbWizard.CTX_DB_CONNECTION);

    Boolean supportSl = (Boolean)wizardContext.getAttribute(GwsbWizard.CTX_SUPPORT_SL);
    if (supportSl == null)
      supportSl = new Boolean(false);

    LinkedList inputData = (LinkedList)wizardContext.getAttribute(GwsbWizard.CTX_INPUT_DATA);
    HashMap[] maps = (HashMap[])wizardContext.getAttribute(GwsbWizard.CTX_HASH_MAPS);
    File sqlFile = (File)wizardContext.getAttribute(GwsbWizard.CTX_SQL_FILE);
    File errorFile = (File)wizardContext.getAttribute(GwsbWizard.CTX_ERROR_FILE);

    HashMap categoryMap    = maps[0];              // Gewerke-Ids
    HashMap akMap          = maps[1];              // AK-Ids
    HashMap processMap     = maps[2];              // T�tigkeits-Ids
    HashMap contractMap    = maps[3];              // Vertrags-Ids
    HashMap applicationMap = maps[4];              // Application-Ids

    TreeSet slSet = new TreeSet();                 // Service level set

    progressBar.setString("Fortschritt");
    progressBar.setValue(0);
    try
    {
      // open output files
      PrintWriter sqlWriter = new PrintWriter(new FileWriter(sqlFile));
      PrintWriter errorWriter = new PrintWriter(new FileWriter(errorFile));

      int maxIdx = inputData.size();
      int idx = 0;
      Iterator i = inputData.iterator();
      while (i.hasNext())
      {
        setProcessValue(idx++, maxIdx);
        GwsbData data = (GwsbData)i.next();
        if (data.isValid() && data.getErrorMessage() == null)
        {
          String categoryKey = (String)categoryMap.get(data.getCategory());
          if (categoryKey == null)
            data.addErrorMessage("Gewerk fehlerhaft");
          String akKey = (String)akMap.get(data.getAk());
          if (akKey == null)
            data.addErrorMessage("AK fehlerhaft");
          String processKey = (String)processMap.get(data.getProcess());
          if (processKey == null)
            data.addErrorMessage("T�tigkeit fehlerhaft");
          String contractKey = (String)contractMap.get(data.getContract());
          if (contractKey == null)
            data.addErrorMessage("Vertrag fehlerhaft");
          if (data.getApplicationKey() > 0 && applicationMap.get(new Long(data.getApplicationKey())) == null)
            data.addErrorMessage("Applikation fehlerhaft");

          if (data.getErrorMessage() == null)
          {
            StringBuffer delCmd = new StringBuffer("DELETE FROM CATEGORYPROCESS");
            delCmd.append(" WHERE CATEGORY_KEY='").append(categoryKey).append("'");
            delCmd.append(" AND WORKGROUP_KEY='").append(akKey).append("'");
            delCmd.append(" AND PROCESS_KEY='").append(processKey).append("'");
            delCmd.append(" AND CONTRACT_KEY='").append(contractKey).append("'");
            delCmd.append(";");
            sqlWriter.println(delCmd.toString());
            executeSql(connection, data, delCmd.toString());

            if (!data.isDeleteOnly())
            {
              StringBuffer sqlCmd = new StringBuffer("INSERT INTO CATEGORYPROCESS");
              sqlCmd.append(" (CATEGORY_KEY,ROUTINGINFO,WORKGROUP_KEY,PROCESS_KEY,CONTRACT_KEY,APPLICATION_KEY)");
              sqlCmd.append(" VALUES (");
              sqlCmd.append("'").append(categoryKey).append("'");
              if (data.getRoutinginfo() != null)
                sqlCmd.append(",'").append(data.getRoutinginfo()).append("'");
              else
                sqlCmd.append(",NULL");
              sqlCmd.append(",'").append(akKey).append("'");
              sqlCmd.append(",'").append(processKey).append("'");
              sqlCmd.append(",'").append(contractKey).append("'");
              if (data.getApplicationKey() > 0)
                sqlCmd.append(",'").append(data.getApplicationKey()).append("'");
              else
                sqlCmd.append(",NULL");
              sqlCmd.append(");");
              sqlWriter.println(sqlCmd.toString());
              executeSql(connection, data, sqlCmd.toString());

              if (supportSl.booleanValue())
              {
                sqlCmd = new StringBuffer("INSERT INTO CONTRACTSL");
                sqlCmd.append(" (CATEGORY_KEY,PROCESS_KEY,SL,KSL,CONTRACT_KEY)");
                sqlCmd.append(" VALUES (");
                sqlCmd.append("'").append(categoryKey).append("'");
                sqlCmd.append(",'").append(processKey).append("'");
                if (data.getSl() > 0)
                  sqlCmd.append(",'").append(data.getSl()).append("'");
                else
                  sqlCmd.append(",NULL");
                if (data.getKsl() > 0)
                  sqlCmd.append(",'").append(data.getKsl()).append("'");
                else
                  sqlCmd.append(",NULL");
                sqlCmd.append(",'").append(contractKey).append("'");
                sqlCmd.append(");");
                
                if (!slSet.contains(sqlCmd.toString()))
                {
                  delCmd = new StringBuffer("DELETE FROM CONTRACTSL");
                  delCmd.append(" WHERE CATEGORY_KEY='").append(categoryKey).append("'");
                  delCmd.append(" AND PROCESS_KEY='").append(processKey).append("'");
                  delCmd.append(" AND CONTRACT_KEY='").append(contractKey).append("'");
                  delCmd.append(";");
                  sqlWriter.println(delCmd.toString());
                  executeSql(connection, data, delCmd.toString());
                  sqlWriter.println(sqlCmd.toString());
                  executeSql(connection, data, sqlCmd.toString());
                  
                  slSet.add(sqlCmd.toString());
                }
              }
            }
            sqlWriter.flush();
          }
        }
        if (!data.isValid() || data.getErrorMessage() != null)
          errorWriter.println(data);
      }

      sqlWriter.flush();
      errorWriter.flush();

      errorMessage = null;
      progressBar.setString("Fertig");
      progressBar.setValue(100);
    }
    catch (Exception e)
    {
      progressBar.setString("Fehler");
      errorMessage = "Error: " + e.toString();
    }

    setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
    activity = null;
  }
  
  /**
   * Returns false because there is no successor panel.
   */
  public boolean hasNext()
  {
    return false;
  }

  /**
   * Returns false because there is no successor panel.
   */
  public boolean validateNext(List list)
  {
    return false;
  }

  /**
   * Returns null because there is no successor panel.
   */
  public WizardPanel next()
  {
    return null;
  }

  /**
   * Returns true, because this panel can finish the wizard
   */
  public boolean canFinish()
  {
    return true;
  }

  /**
   * Empty method.
   */
  public boolean validateFinish(List list)
  {
    if (activity == null && (errorMessage == null || errorMessage.length() == 0))
      return true;

    if (activity != null)
      list.add("Aktivit�t noch nicht abgeschlossen");

    list.add(errorMessage);
    return false;
  }

  /**
   * Empty method.
   */
  public void finish()
  {
  }

  /**
   * Sets the value of the progress bar.
   */
  private void setProcessValue(int current, int max)
  {
    if (max > 0)
    {
      int value = (100*(current + 1))/max;
      if (value != progressBar.getValue())
        progressBar.setValue(value);
    }
  }

  /**
   * Executes the specified sql command.
   */
  private void executeSql(Connection connection, GwsbData data, String sqlCmd)
  {
    if (connection == null)
      return;

    try
    {
      Statement statement = connection.createStatement();
      statement.executeQuery(sqlCmd.substring(0, sqlCmd.length()-1));
      statement.close();
    }
    catch (SQLException e)
    {
      data.addErrorMessage(e.toString());
    }
  }
}
