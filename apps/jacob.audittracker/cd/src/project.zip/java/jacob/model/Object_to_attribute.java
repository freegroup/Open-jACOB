/**************************************************************************
 * Project  : jacob.audittracker
 * Date     : Tue Apr 10 21:35:36 CEST 2007
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.model;

public final class Object_to_attribute
{
   private Object_to_attribute(){}

   // the name of the table alias	 
   public final static String NAME = "object_to_attribute";
	 
   // All field names of the table alias "object_to_attribute"
   /** 
     required: true<br>
     type:     LONG<br>
   */
   public final static String  pkey = "pkey";
   
   /** 
     required: false<br>
     type:     LONG<br>
   */
   public final static String  attribute_key = "attribute_key";
   
   /** 
     required: false<br>
     type:     LONG<br>
   */
   public final static String  object_key = "object_key";
   
	 
         
}