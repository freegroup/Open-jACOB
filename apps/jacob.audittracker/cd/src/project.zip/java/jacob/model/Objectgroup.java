/**************************************************************************
 * Project  : jacob.audittracker
 * Date     : Tue Apr 10 21:35:36 CEST 2007
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.model;

public final class Objectgroup
{
   private Objectgroup(){}

   // the name of the table alias	 
   public final static String NAME = "objectgroup";
	 
   // All field names of the table alias "objectgroup"
   /** 
     required: true<br>
     type:     LONG<br>
   */
   public final static String  pkey = "pkey";
   
   /** 
     required: false<br>
     type:     TEXT<br>
   */
   public final static String  name = "name";
   
   /** 
     required: false<br>
     type:     LONG<br>
   */
   public final static String  parentobjectgroup_key = "parentobjectgroup_key";
   
   /** 
     required: false<br>
     type:     TEXT<br>
   */
   public final static String  longname = "longname";
   
	 
            
}