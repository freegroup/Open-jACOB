/**************************************************************************
 * Project  : jacob.audittracker
 * Date     : Tue Apr 10 21:35:36 CEST 2007
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.model;

public final class Template
{
   private Template(){}

   // the name of the table alias	 
   public final static String NAME = "template";
	 
   // All field names of the table alias "template"
   /** 
     required: true<br>
     type:     LONG<br>
   */
   public final static String  pkey = "pkey";
   
   /** 
     required: false<br>
     type:     DOCUMENT<br>
   */
   public final static String  document = "document";
   
   /** 
     required: false<br>
     type:     TEXT<br>
   */
   public final static String  name = "name";
   
	 
         
}