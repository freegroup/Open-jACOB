package jacob.resources;

/**
 * The ResourceProvider.java is a generated file! 
 *
 * !!! DO NOT EDIT NOR DELETE THIS FILE !!!
 * 
 * This is the anchor class to easily locate gif/jpeg image and resource bundles
 * for the jACOB application server.
 * 
 * Note: Each form must have a GIF image which will be shown in the navigation bar.
 *       The name of the GIF image must match to the form name, i.e. formname.gif .
 */
public class ResourceProvider
{
	// no code needed here!
}
