/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:19 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.relationset;


/**
 *
 **/
public final class SubvdnRelationset
{
   private SubvdnRelationset(){}

   // the name of the table alias	 
   public final static String NAME = "subvdnRelationset";
}