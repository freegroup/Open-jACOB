/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>numbercountry</b>
 *
 **/
public final class NumbercountryBrowser
{
   private NumbercountryBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "numbercountryBrowser";
	 
   // All field names of the browser "numbercountryBrowser"
   public final static String  browserCountry = "browserCountry";
   public final static String  browserAlpha2 = "browserAlpha2";
   public final static String  browserAlpha3 = "browserAlpha3";
   public final static String  browserNumeric = "browserNumeric";
   public final static String  browserCallingcode = "browserCallingcode";

}