/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:25 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>ldapaccount</b>
 *
 **/
public final class LdapaccountBrowser
{
   private LdapaccountBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "ldapaccountBrowser";
	 
   // All field names of the browser "ldapaccountBrowser"
   public final static String  browserDisplayname = "browserDisplayname";
   public final static String  browserLoginname = "browserLoginname";

}