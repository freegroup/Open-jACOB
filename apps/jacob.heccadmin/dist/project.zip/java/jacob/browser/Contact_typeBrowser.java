/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>contact_type</b>
 *
 **/
public final class Contact_typeBrowser
{
   private Contact_typeBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "contact_typeBrowser";
	 
   // All field names of the browser "contact_typeBrowser"
   public final static String  browserType = "browserType";
   public final static String  browserMediatype = "browserMediatype";
   public final static String  browserCti_enabled = "browserCti_enabled";
   public final static String  browserValidation_method = "browserValidation_method";
   public final static String  browserValidation_expression = "browserValidation_expression";

}