/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>number</b>
 *
 **/
public final class NumberBrowser
{
   private NumberBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "numberBrowser";
	 
   // All field names of the browser "numberBrowser"
   public final static String  browserNumbercountry = "browserNumbercountry";
   public final static String  browserNumbervendor = "browserNumbervendor";
   public final static String  browserNumberaccount = "browserNumberaccount";
   public final static String  browserNumberusagetype = "browserNumberusagetype";
   public final static String  browserNumbertype = "browserNumbertype";
   public final static String  browserCircuits = "browserCircuits";
   public final static String  browserLocalnumber = "browserLocalnumber";
   public final static String  browserNumbercountry1 = "browserNumbercountry1";
   public final static String  browserNumbervdn = "browserNumbervdn";
   public final static String  browserNumberstatus = "browserNumberstatus";
   public final static String  browserActive = "browserActive";

}