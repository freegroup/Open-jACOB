/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>vdnapplication</b>
 *
 **/
public final class VdnapplicationBrowser
{
   private VdnapplicationBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "vdnapplicationBrowser";
	 
   // All field names of the browser "vdnapplicationBrowser"
   public final static String  browserName = "browserName";
   public final static String  browserStatus = "browserStatus";

}