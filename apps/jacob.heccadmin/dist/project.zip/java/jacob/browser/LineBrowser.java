/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>line</b>
 *
 **/
public final class LineBrowser
{
   private LineBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "lineBrowser";
	 
   // All field names of the browser "lineBrowser"
   public final static String  browserPkey = "browserPkey";
   public final static String  browserLine = "browserLine";
   public final static String  browserActive = "browserActive";

}