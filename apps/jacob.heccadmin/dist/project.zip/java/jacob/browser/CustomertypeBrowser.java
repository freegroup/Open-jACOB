/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>customertype</b>
 *
 **/
public final class CustomertypeBrowser
{
   private CustomertypeBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "customertypeBrowser";
	 
   // All field names of the browser "customertypeBrowser"
   public final static String  browserCustomertype = "browserCustomertype";

}