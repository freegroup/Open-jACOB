/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>numbertype</b>
 *
 **/
public final class NumbertypeBrowser
{
   private NumbertypeBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "numbertypeBrowser";
	 
   // All field names of the browser "numbertypeBrowser"
   public final static String  browserNumbertype = "browserNumbertype";
   public final static String  browserRequirespassages = "browserRequirespassages";

}