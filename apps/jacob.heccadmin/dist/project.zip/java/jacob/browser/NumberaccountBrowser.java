/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>numberaccount</b>
 *
 **/
public final class NumberaccountBrowser
{
   private NumberaccountBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "numberaccountBrowser";
	 
   // All field names of the browser "numberaccountBrowser"
   public final static String  browserAccount = "browserAccount";
   public final static String  browserActive = "browserActive";

}