/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>emailapplication</b>
 *
 **/
public final class EmailapplicationBrowser
{
   private EmailapplicationBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "emailapplicationBrowser";
	 
   // All field names of the browser "emailapplicationBrowser"
   public final static String  browserName = "browserName";
   public final static String  browserStatus = "browserStatus";

}