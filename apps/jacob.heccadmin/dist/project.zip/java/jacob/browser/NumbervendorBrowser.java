/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>numbervendor</b>
 *
 **/
public final class NumbervendorBrowser
{
   private NumbervendorBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "numbervendorBrowser";
	 
   // All field names of the browser "numbervendorBrowser"
   public final static String  browserVendor = "browserVendor";

}