/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>direction</b>
 *
 **/
public final class DirectionBrowser
{
   private DirectionBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "directionBrowser";
	 
   // All field names of the browser "directionBrowser"
   public final static String  browserDirection = "browserDirection";

}