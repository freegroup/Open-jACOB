/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>numberusagetype</b>
 *
 **/
public final class NumberusagetypeBrowser
{
   private NumberusagetypeBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "numberusagetypeBrowser";
	 
   // All field names of the browser "numberusagetypeBrowser"
   public final static String  browserUsagetype = "browserUsagetype";

}