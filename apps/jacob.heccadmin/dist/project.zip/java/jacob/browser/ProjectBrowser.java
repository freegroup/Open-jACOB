/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>project</b>
 *
 **/
public final class ProjectBrowser
{
   private ProjectBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "projectBrowser";
	 
   // All field names of the browser "projectBrowser"
   public final static String  browserPkey = "browserPkey";
   public final static String  browserProject = "browserProject";
   public final static String  browserDatabase = "browserDatabase";
   public final static String  browserApplication = "browserApplication";
   public final static String  browserActive = "browserActive";

}