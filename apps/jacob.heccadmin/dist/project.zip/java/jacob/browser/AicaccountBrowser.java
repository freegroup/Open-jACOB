/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:25 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>aicaccount</b>
 *
 **/
public final class AicaccountBrowser
{
   private AicaccountBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "aicaccountBrowser";
	 
   // All field names of the browser "aicaccountBrowser"
   public final static String  browserLoginname = "browserLoginname";
   public final static String  browserFullname = "browserFullname";

}