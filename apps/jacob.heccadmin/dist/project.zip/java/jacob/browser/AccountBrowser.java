/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>account</b>
 *
 **/
public final class AccountBrowser
{
   private AccountBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "accountBrowser";
	 
   // All field names of the browser "accountBrowser"
   public final static String  browserPkey = "browserPkey";
   public final static String  browserAccount = "browserAccount";
   public final static String  browserActive = "browserActive";

}