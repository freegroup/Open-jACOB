/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>sacschemas</b>
 *
 **/
public final class SacschemasBrowser
{
   private SacschemasBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "sacschemasBrowser";
	 
   // All field names of the browser "sacschemasBrowser"
   public final static String  browserLeadingNumber = "browserLeadingNumber";
   public final static String  browserBaseCallLimit = "browserBaseCallLimit";
   public final static String  browserDigitLength = "browserDigitLength";
   public final static String  browserDescription = "browserDescription";
   public final static String  browserTotalGenerated = "browserTotalGenerated";

}