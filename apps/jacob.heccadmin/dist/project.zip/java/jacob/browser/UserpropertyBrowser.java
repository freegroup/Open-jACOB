/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>userproperty</b>
 *
 **/
public final class UserpropertyBrowser
{
   private UserpropertyBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "userpropertyBrowser";
	 
   // All field names of the browser "userpropertyBrowser"
   public final static String  browserProperty = "browserProperty";
   public final static String  browserUser = "browserUser";
   public final static String  browserValue = "browserValue";

}