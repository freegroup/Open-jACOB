/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>gender</b>
 *
 **/
public final class GenderBrowser
{
   private GenderBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "genderBrowser";
	 
   // All field names of the browser "genderBrowser"
   public final static String  browserGender = "browserGender";

}