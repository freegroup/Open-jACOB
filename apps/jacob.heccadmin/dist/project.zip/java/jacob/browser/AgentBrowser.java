/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:25 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>agent</b>
 *
 **/
public final class AgentBrowser
{
   private AgentBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "agentBrowser";
	 
   // All field names of the browser "agentBrowser"
   public final static String  browserLdapaccount = "browserLdapaccount";
   public final static String  browserLdapaccountTable = "browserLdapaccountTable";
   public final static String  browserAgentid = "browserAgentid";
   public final static String  browserSite = "browserSite";

}