/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>projectapplication</b>
 *
 **/
public final class ProjectapplicationBrowser
{
   private ProjectapplicationBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "projectapplicationBrowser";
	 
   // All field names of the browser "projectapplicationBrowser"
   public final static String  browserName = "browserName";
   public final static String  browserStatus = "browserStatus";

}