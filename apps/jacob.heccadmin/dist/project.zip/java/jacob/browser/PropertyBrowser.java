/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>property</b>
 *
 **/
public final class PropertyBrowser
{
   private PropertyBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "propertyBrowser";
	 
   // All field names of the browser "propertyBrowser"
   public final static String  browserProperty = "browserProperty";
   public final static String  browserDescription = "browserDescription";
   public final static String  browserValue = "browserValue";

}