/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>numbervdn</b>
 *
 **/
public final class NumbervdnBrowser
{
   private NumbervdnBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "numbervdnBrowser";
	 
   // All field names of the browser "numbervdnBrowser"
   public final static String  browserVdnnumber = "browserVdnnumber";
   public final static String  browserVdnname = "browserVdnname";
   public final static String  browserActive = "browserActive";

}