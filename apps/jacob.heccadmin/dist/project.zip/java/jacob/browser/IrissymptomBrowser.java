/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>irissymptom</b>
 *
 **/
public final class IrissymptomBrowser
{
   private IrissymptomBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "irissymptomBrowser";
	 
   // All field names of the browser "irissymptomBrowser"
   public final static String  browserIriscode = "browserIriscode";
   public final static String  browserIristext = "browserIristext";
   public final static String  browserIrissymptom = "browserIrissymptom";

}