/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>requeststatus</b>
 *
 **/
public final class RequeststatusBrowser
{
   private RequeststatusBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "requeststatusBrowser";
	 
   // All field names of the browser "requeststatusBrowser"
   public final static String  browserStatus = "browserStatus";
   public final static String  browserSortorder = "browserSortorder";

}