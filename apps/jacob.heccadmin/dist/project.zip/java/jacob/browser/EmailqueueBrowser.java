/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>emailqueue</b>
 *
 **/
public final class EmailqueueBrowser
{
   private EmailqueueBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "emailqueueBrowser";
	 
   // All field names of the browser "emailqueueBrowser"
   public final static String  browserQueueid = "browserQueueid";
   public final static String  browserQueuename = "browserQueuename";

}