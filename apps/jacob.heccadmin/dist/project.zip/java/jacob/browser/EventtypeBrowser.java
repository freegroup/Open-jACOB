/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>eventtype</b>
 *
 **/
public final class EventtypeBrowser
{
   private EventtypeBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "eventtypeBrowser";
	 
   // All field names of the browser "eventtypeBrowser"
   public final static String  browserEventtype = "browserEventtype";

}