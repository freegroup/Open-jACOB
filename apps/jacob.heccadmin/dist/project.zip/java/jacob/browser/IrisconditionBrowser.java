/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>iriscondition</b>
 *
 **/
public final class IrisconditionBrowser
{
   private IrisconditionBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "irisconditionBrowser";
	 
   // All field names of the browser "irisconditionBrowser"
   public final static String  browserIriscode = "browserIriscode";
   public final static String  browserIriscondition = "browserIriscondition";

}