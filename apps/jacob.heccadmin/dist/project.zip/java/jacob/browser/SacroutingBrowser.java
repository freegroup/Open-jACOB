/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>sacrouting</b>
 *
 **/
public final class SacroutingBrowser
{
   private SacroutingBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "sacroutingBrowser";
	 
   // All field names of the browser "sacroutingBrowser"
   public final static String  browserVdn = "browserVdn";
   public final static String  browserSacroutingschema = "browserSacroutingschema";
   public final static String  browserSacrouting = "browserSacrouting";
   public final static String  browserSubvdn = "browserSubvdn";
   public final static String  browserTargetnumber = "browserTargetnumber";
   public final static String  browserOutboundcode = "browserOutboundcode";
   public final static String  browserActive = "browserActive";

}