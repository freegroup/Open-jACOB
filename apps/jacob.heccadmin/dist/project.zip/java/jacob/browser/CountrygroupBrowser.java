/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>countrygroup</b>
 *
 **/
public final class CountrygroupBrowser
{
   private CountrygroupBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "countrygroupBrowser";
	 
   // All field names of the browser "countrygroupBrowser"
   public final static String  browserCountrygroup = "browserCountrygroup";

}