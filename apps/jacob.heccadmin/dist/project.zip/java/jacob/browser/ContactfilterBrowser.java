/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>contactfilter</b>
 *
 **/
public final class ContactfilterBrowser
{
   private ContactfilterBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "contactfilterBrowser";
	 
   // All field names of the browser "contactfilterBrowser"
   public final static String  browserMediatype = "browserMediatype";
   public final static String  browserFilter = "browserFilter";
   public final static String  browserDescription = "browserDescription";
   public final static String  browserActive = "browserActive";

}