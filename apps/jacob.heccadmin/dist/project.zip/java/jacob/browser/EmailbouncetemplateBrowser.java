/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>emailbouncetemplate</b>
 *
 **/
public final class EmailbouncetemplateBrowser
{
   private EmailbouncetemplateBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "emailbouncetemplateBrowser";
	 
   // All field names of the browser "emailbouncetemplateBrowser"
   public final static String  browserName = "browserName";
   public final static String  browserLanguagecode = "browserLanguagecode";

}