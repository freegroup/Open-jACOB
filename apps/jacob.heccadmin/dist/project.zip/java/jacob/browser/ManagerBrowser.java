/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:25 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>manager</b>
 *
 **/
public final class ManagerBrowser
{
   private ManagerBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "managerBrowser";
	 
   // All field names of the browser "managerBrowser"
   public final static String  browserLdapaccount = "browserLdapaccount";
   public final static String  browserLdapmanageraccount = "browserLdapmanageraccount";

}