/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>subvdn</b>
 *
 **/
public final class SubvdnBrowser
{
   private SubvdnBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "subvdnBrowser";
	 
   // All field names of the browser "subvdnBrowser"
   public final static String  browserVdnnumber = "browserVdnnumber";
   public final static String  browserVdnname = "browserVdnname";
   public final static String  browserMenuoption = "browserMenuoption";
   public final static String  browserActive = "browserActive";

}