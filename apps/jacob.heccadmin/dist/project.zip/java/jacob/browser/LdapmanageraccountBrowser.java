/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:25 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>ldapmanageraccount</b>
 *
 **/
public final class LdapmanageraccountBrowser
{
   private LdapmanageraccountBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "ldapmanageraccountBrowser";
	 
   // All field names of the browser "ldapmanageraccountBrowser"
   public final static String  browserDisplayname = "browserDisplayname";
   public final static String  browserLoginname = "browserLoginname";

}