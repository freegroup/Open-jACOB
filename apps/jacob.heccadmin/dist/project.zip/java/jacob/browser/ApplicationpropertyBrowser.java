/**************************************************************************
 * Project  : jacob.heccadmin
 * Date     : Tue Apr 28 15:04:24 CEST 2009
 * 
 * THIS IS A GENERATED FILE - DO NOT CHANGE!
 *
 *************************************************************************/
package jacob.browser;


/**
 * $browser.description
 *
 * DB alias: <b>applicationproperty</b>
 *
 **/
public final class ApplicationpropertyBrowser
{
   private ApplicationpropertyBrowser(){}

   // the name of the table alias	 
   public final static String NAME = "applicationpropertyBrowser";
	 
   // All field names of the browser "applicationpropertyBrowser"
   public final static String  browserProperty = "browserProperty";
   public final static String  browserApplication = "browserApplication";
   public final static String  browserValue = "browserValue";

}