package jacob.security;

import com.hecc.jacob.ldap.BasicLdapUserFactory;

/**
 * @author R.Spoor
 */
public class UserFactory extends BasicLdapUserFactory
{
    // FIXME: change to standard LdapUserFactory instead
}
