All resources located in this directory are available
with

http://localhost:8080/jacob/application/heccadmin/<VERSION>/